package model;

import store.StuArray;
import store.TeaArray;

public class Teachers extends Person{
	private String tid;

	public Teachers() {
		
	}
	public Teachers(String tid) {
		super();
		this.tid = tid;
	}

	public String getTid() {
		return tid;
	}

	public void setTid(String tid) {
		this.tid = tid;
	}
	
	public Teachers(String id, String tid, String name) {
		super(id, name);
		this.tid = tid;
	}



	private static TeaArray teaArr = new TeaArray();

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Teachers tea = new Teachers();
		for(int i = 0; i < 10000; i++) {
			System.out.println(i);
			tea.teaArr.add(new Teachers(String.valueOf(i)));
			if(i % 10 == 0) {
				tea.teaArr.delete(new Teachers(String.valueOf(i)));
			}
		}
		for(int i = 0; i < TeaArray.getAmount(); i++)
			System.out.println("sid : " + teaArr.getTeaArr()[i].getTid());
		System.out.println(TeaArray.getAmount());
	}

}
