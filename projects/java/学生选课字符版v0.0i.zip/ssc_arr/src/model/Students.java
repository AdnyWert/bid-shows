package model;

import store.StuArray;

public class Students extends Person{
	private String sid;
	public static StuArray stuArr = new StuArray();
	
	public Students() {
		
	}
	public Students(String sid) {
		this.sid = sid;
	}
	
	
	
	public Students(String id, String sid, String name) {
		super(id, name);
		this.sid = sid;
	}
	public String getSid() {
		return sid;
	}

	public void setSid(String sid) {
		this.sid = sid;
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Students stu = new Students();
		for(int i = 0; i < 10000; i++) {
			System.out.println(i);
			stu.stuArr.add(new Students(String.valueOf(i)));
			if(i % 10 == 0) {
				stu.stuArr.delete(new Students(String.valueOf(i)));
			}
		}
		for(int i = 0; i < StuArray.getAmount(); i++)
			System.out.println("sid : " + stuArr.getStuArr()[i].getSid());
		System.out.println(StuArray.getAmount());
	}
}
