package model;

public class CourseScheduling {		// �ſα�
	private String csid;	// �γ̺�
	private String tid;		// ��ʦ���
	private String cid;		// �γ̺�
	
	public CourseScheduling() {
		super();
	}
	
	public CourseScheduling(String csid) {
		super();
		this.csid = csid;
	}
	
	public CourseScheduling(String csid, String tid, String cid) {
		super();
		this.csid = csid;
		this.tid = tid;
		this.cid = cid;
	}

	public String getCsid() {
		return csid;
	}
	public void setCsid(String csid) {
		this.csid = csid;
	}
	public String getTid() {
		return tid;
	}
	public void setTid(String tid) {
		this.tid = tid;
	}
	public String getCid() {
		return cid;
	}
	public void setCid(String cid) {
		this.cid = cid;
	}
	
	
}
