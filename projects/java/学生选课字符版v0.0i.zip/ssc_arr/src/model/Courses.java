package model;

import store.CouArray;


public class Courses {
	private String cid;		// �κ�
	private String name;
	private String credit;	// ѧ��
	
	public String getCid() {
		return cid;
	}

	public void setCid(String cid) {
		this.cid = cid;
	}
	
	
	
	public Courses(String cid, String name, String credit) {
		super();
		this.cid = cid;
		this.name = name;
		this.credit = credit;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Courses(){
		
	}
	public Courses(String cid) {
		this.cid = cid;
	}

	private static CouArray couArr  = new CouArray();
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Courses cou = new Courses();
		for(int i = 0; i < 10000; i++) {
			System.out.println(i);
			cou.couArr.add(new Courses(String.valueOf(i)));
			if(i % 10 == 0) {
				cou.couArr.delete(new Courses(String.valueOf(i)));
			}
		}
		for(int i = 0; i < CouArray.getAmount(); i++)
			System.out.println("sid : " + couArr.getCouArr()[i].getCid());
		System.out.println(CouArray.getAmount());
	}

}
