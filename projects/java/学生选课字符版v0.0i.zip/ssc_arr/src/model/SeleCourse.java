package model;

public class SeleCourse {	// ѡ�α�
	private String scid;	// ѡ�κ�
	private String csid;	// �ſκ�
	private String cid;		// �κ�
	private String sid;		// ѧ��
	
	private static int aScid;
	private static String autoScid() {
		aScid++;
		return String.valueOf(aScid);
	}
	
	public SeleCourse() {
		
	}
	public SeleCourse(String scid) {
		super();
		this.scid = scid;
	}
	
	
	public SeleCourse(String csid, String sid) {
		super();
		this.scid = autoScid();
		this.csid = csid;
		this.sid = sid;
	}


	public String getScid() {
		return scid;
	}
	public void setScid(String scid) {
		this.scid = scid;
	}
	public String getCsid() {
		return csid;
	}
	public void setCsid(String csid) {
		this.csid = csid;
	}
	
	public String getCid() {
		return cid;
	}

	public void setCid(String cid) {
		this.cid = cid;
	}

	public String getSid() {
		return sid;
	}
	public void setSid(String sid) {
		this.sid = sid;
	}
	
	
}
