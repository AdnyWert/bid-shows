package test;

import model.*;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Students stu = new Students();
		for(int i = 0; i <= 10000; i++) {
//			stu.stuArr.add(new Students(String.valueOf(i)));
//			System.out.println(Randomscid());
		}
		System.out.println("1 2 3 4 5".trim());
			
	}
	public static String Randomscid() {  // 00001 ~ 99999
		return String.format("%05d", (int) (Math.random() * 100000 + 1));
	}

}
