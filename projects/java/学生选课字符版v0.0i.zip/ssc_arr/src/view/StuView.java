package view;

import java.util.Scanner;

import model.CourseScheduling;
import model.Courses;
import model.SeleCourse;
import model.Students;
import model.Teachers;
import store.CSArray;
import store.CouArray;
import store.SCArray;
import store.TeaArray;

public class StuView {
	private Scanner sc = new Scanner(System.in);
	public void disMenu() {
		System.out.println("0: �˳�ѡ��");
		System.out.println("1: �鿴ѡ��");
		System.out.println("2: �鿴�ſα�");
		System.out.println("3: ����ѡ��");
		System.out.println("4: ɾ��ѡ��");
		System.out.print("��������ѡ��Ĺ���: ");
	}
	
	public void StuMain(Students stu) {
		boolean exiT = true;
		int option;
		while(exiT) {
			disMenu(); option = sc.nextInt();
			switch(option) {
				case 1:
					System.out.println("--- ѡ�κ� ------- �γ�����  ---------");
					for(SeleCourse x: new SCArray().showBySid(stu))
						if(x != null)
							System.out.printf("%9s\t%s\n", x.getScid(), new CouArray().couByTid(new Courses(x.getCid())).getName());
						else
							break;
						; break;
				case 2: 
					System.out.println("--- �γ̺� ------- �γ�����  --------- ��ʦ ---");
					for(CourseScheduling y: new CSArray().show())
						if(y != null)
							System.out.printf("%9s\t%-20.20s\t%10s\n", y.getCsid(), new CouArray().couByTid(new Courses(y.getCid())).getName() 
									, new TeaArray().teaByTid(new Teachers(y.getTid())).getName());
						else
							break;
						; break;
				case 3: 
						System.out.print("������κ�: "); 
						if(SCArray.add(new SeleCourse(sc.next(), stu.getSid())))
							System.out.println("�ɹ�ѡ��");
						else
							System.out.println("ѡ��ʧ��");
						; break;
				case 4: 
					System.out.print("������κ�: "); 
					if(SCArray.delete(new SeleCourse(sc.next())))
						System.out.println("�ɹ��˿�");
					else
						System.out.println("�˿�ʧ��");
					; break;
				case 0: exiT = false; break;
				default:
					System.out.println("ѡ�����,����������");
			}
			if(exiT) {	// ����س�����
				sc.nextLine();
				while(!sc.nextLine().trim().isEmpty());
			}
		}
	}
}
