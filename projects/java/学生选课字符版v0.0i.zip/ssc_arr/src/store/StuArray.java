package store;

import model.Students;
import model.Teachers;

public class StuArray{
	private static int amount;
	private static int length;
	private static int offset;		// ����������� 0
	private static Students[] stuArr;
	
	static {	// ��ʼ��
		offset = 10;
		stuArr = new Students[length];
	}
	
	public static boolean add(Students stu) {	// ����һ��ѧ��
		boolean state = true;
		for(int i = 0; i < amount; i++)
			if(stuArr[i].getSid().equals(stu.getSid())) {		// �ж�ѧ���Ƿ����
				state = false; break;
			}
		if(state) {
			if(amount >= length) // ���ݳ��ȴ������鳤��
				stuArr = move(stuArr, length, offset);
			stuArr[amount++] = stu;
		}
		
		return state;
	}
	
	public static boolean delete(Students stu) {		// ɾ��һ��ѧ��
		boolean state = false;
		for(int i = 0; i < amount; i++)
			if(stuArr[i].getSid().equals(stu.getSid())) {
				
				System.arraycopy(stuArr, i+1, stuArr, i, amount-i);	// ����ת��
				amount--; stuArr[amount] = null;
				state = true;
				break;
			}
		
		return state;
	}
	
	public static Students[] move(Students[] stuArr, int length, int offset) {	// ����ת��
		StuArray.length = length + offset;
		Students[] newStuArr = new Students[StuArray.length];
		System.arraycopy(stuArr, 0, newStuArr, 0, amount);	// ����ת��
		return newStuArr;
	}

	
	public static Students stuBySid(Students stu) {
		Students ans = null;
		for(Students x: stuArr) {
			if(x == null)
				break;
			if(x.getSid().equals(stu.getSid())) {
				ans = x;
				break;
			}
		}		
		return ans;
	}
	
	
	public static boolean isExist(Students stu) {
		boolean state = false;
		for(Students x: stuArr) {
			if(x == null) break;
			if(x.getSid().equals(stu.getSid())) {
				state = true; break;
			}
		}
		return state;
	}
	
	public static int getOffset() {
		return offset;
	}

	public static void setOffset(int offset) {
		StuArray.offset = offset;
	}

	public static int getAmount() {
		return amount;
	}

	public static int getLength() {
		return length;
	}

	public static Students[] getStuArr() {
		return stuArr;
	}
	
}

