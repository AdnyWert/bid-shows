package store;


import model.CourseScheduling;
import model.Courses;
import model.Students;

public class CSArray {
	private static int amount;
	private static int length;
	private static int offset;		// ����������� 0
	private static CourseScheduling[] CouSchArr;
	
	static {	// ��ʼ��
		offset = 10;
		CouSchArr = new CourseScheduling[length];
	}
	
	public static boolean add(CourseScheduling cousch) {	// ����һ���γ�
		boolean state = true;
		for(int i = 0; i < amount; i++)
			if(CouSchArr[i].getTid().equals(cousch.getTid()) && CouSchArr[i].getCid().equals(cousch.getCid())) {		// �ж�ѧ���Ƿ����
				state = false; break;
			}
		if(state) {
			if(amount >= length) // ���ݳ��ȴ������鳤��
				CouSchArr = move(length, offset);
			CouSchArr[amount++] = cousch;
		}
		return state;
	}
	
	public static boolean delete(CourseScheduling cousch) {		// ɾ��һ���γ�
		boolean state = false;
		for(int i = 0; i < amount; i++)
			if(CouSchArr[i].getCsid().equals(cousch.getCsid())) {
				System.arraycopy(CouSchArr, i+1, CouSchArr, i, amount-i);	// ����ת��
				amount--; CouSchArr[amount] = null;
				state = true;
				break;
			}
		
		return state;
	}
	
	public static CourseScheduling[] show() {
		return CouSchArr;
	}
	
	
	public static CourseScheduling[] move(int length, int offset) {	// ����ת��
		CSArray.length = length + offset;
		CourseScheduling[] newcouschArr = new CourseScheduling[CSArray.length];
		System.arraycopy(CouSchArr, 0, newcouschArr, 0, amount);	// ����ת��
		return newcouschArr;
	}
	
	public static CourseScheduling csByCsid(CourseScheduling cousch) {
		CourseScheduling ans = null;
		for(CourseScheduling x: CouSchArr) {
			if(x == null) break;
			if(x.getCsid().equals(cousch.getCsid())) {
				ans = x;
				break;
			}
		}
		return ans;
	}
	
	public static boolean isExist(CourseScheduling cousch) {
		boolean state = false;
		for(CourseScheduling x: CouSchArr) {
			if(x == null) break;
			if(x.getCsid().equals(cousch.getCsid()) || x.getTid().equals(cousch.getTid()) && x.getCid().equals(cousch.getCid())) {
				state = true; break;
			}
		}
		return state;
	}
	
	
	public static int getOffset() {
		return offset;
	}

	public static void setOffset(int offset) {
		CSArray.offset = offset;
	}

	public static int getAmount() {
		return amount;
	}

	public static int getLength() {
		return length;
	}

	public static CourseScheduling[] getCouSchArr() {
		return CouSchArr;
	}
}
