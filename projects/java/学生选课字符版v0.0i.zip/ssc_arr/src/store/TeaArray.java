package store;

import model.Teachers;

public class TeaArray {
	private static int amount;
	private static int length;
	private static int offset;		// ����������� 0
	private static Teachers[] TeaArr;
	
	static {	// ��ʼ��
		offset = 10;
		TeaArr = new Teachers[length];
	}
	
	public static boolean add(Teachers tea) {	// ����һ��ѧ��
		boolean state = true;
		for(int i = 0; i < amount; i++)
			if(TeaArr[i].getTid().equals(tea.getTid())) {		// �ж�ѧ���Ƿ����
				state = false; break;
			}
		if(state) {
			if(amount >= length) // ���ݳ��ȴ������鳤��
				TeaArr = move(TeaArr, length, offset);
			TeaArr[amount++] = tea;
		}
		
		return state;
	}
	
	public static boolean delete(Teachers tea) {		// ɾ��һ��ѧ��
		boolean state = false;
		for(int i = 0; i < amount; i++)
			if(TeaArr[i].getTid().equals(tea.getTid())) {
				System.arraycopy(TeaArr, i+1, TeaArr, i, amount-i);	// ����ת��
				amount--; TeaArr[amount] = null;
				state = true;
				break;
			}
		
		return state;
	}
	
	public static Teachers[] move(Teachers[] TeaArr, int length, int offset) {	// ����ת��
		TeaArray.length = length + offset;
		Teachers[] newTeaArr = new Teachers[TeaArray.length];
		System.arraycopy(TeaArr, 0, newTeaArr, 0, amount);	// ����ת��
		return newTeaArr;
	}

	public static Teachers teaByTid(Teachers tea) {
		Teachers ans = null;
		for(Teachers x: TeaArr) {
			if(x == null)
				break;
			if(x.getTid().equals(tea.getTid())) {
				
				ans = x;
				break;
			}
		}		
		return ans;
	}
	
	public static boolean isExist(Teachers tea) {
		boolean state = false;
		for(Teachers x:TeaArr) {
			if(x == null) break;
			if(x.getTid().equals(tea.getTid())) {
				state = true; break;
			}
		}
		return state;
	}
	
	public static int getOffset() {
		return offset;
	}

	public static void setOffset(int offset) {
		TeaArray.offset = offset;
	}

	public static int getAmount() {
		return amount;
	}

	public static int getLength() {
		return length;
	}

	public static Teachers[] getTeaArr() {
		return TeaArr;
	}
}
