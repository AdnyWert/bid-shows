package store;

import java.util.Random;

import model.CourseScheduling;
import model.SeleCourse;
import model.Students;
import model.Teachers;


public class SCArray {
	private static int amount;
	private static int length;
	private static int offset;		// ����������� 0
	private static SeleCourse[] SelCouArr;
	
	static {	// ��ʼ��
		offset = 10;
		SelCouArr = new SeleCourse[length];
	}
	
	public static boolean add(SeleCourse selcou) {	// ����һ��ѡ��
		boolean state = true;
		if(selcou == null)
			state = false;
		else if(!CSArray.isExist(new CourseScheduling(selcou.getCsid())))	// �жϿγ̺��Ƿ����
			state = false;
		else
			for(int i = 0; i < amount; i++)
				if(SelCouArr[i].getSid().equals(selcou.getSid()) && SelCouArr[i].getCid().equals(CSArray.csByCsid(new CourseScheduling(selcou.getCsid())).getCid())) {		// �ж�һ��ѧ���Ƿ�ͬʱѡ��ͬһ�ſζ��
					state = false; break;
				}
		if(state) {
			if(amount >= length) // ���ݳ��ȴ������鳤��
				SelCouArr = move(length, offset);
			state = false;
			String scid = Randomscid(); int i = 0;		// �Զ����� scid ��
			while(i++ < 10000) {	// ���ѭ�� 100000��
				if(!isExist(new SeleCourse())) {
					state = true;
					break;
				}
			}
			if(state) {
				selcou.setScid(scid);
				selcou.setCid(CSArray.csByCsid(new CourseScheduling(selcou.getCsid())).getCid());
				SelCouArr[amount++] = selcou;
			}
		}
		return state;
	}
	
	
	public static boolean delete(SeleCourse selcou) {		// ɾ��һ��ѡ��
		boolean state = false;
		for(int i = 0; i < amount; i++)
			if( SelCouArr[i].getScid().equals(selcou.getScid())) {
				System.arraycopy(SelCouArr, i+1, SelCouArr, i, amount-i);	// ����ת��
				amount--; SelCouArr[amount] = null;
				state = true;
				break;
			}
		
		return state;
	}
	
	public static SeleCourse[] move(int length, int offset) {	// ����ת��
		SCArray.length = length + offset;
		SeleCourse[] newselcouArr = new SeleCourse[SCArray.length];
		System.arraycopy(SelCouArr, 0, newselcouArr, 0, amount);	// ����ת��
		return newselcouArr;
	}
	
	public SeleCourse[] showBySid(Students stu) {
		int number = 0; // ��ѯ����ѡ������
		int MAXN = 100;	// ��෵��100��ѡ����Ϣ
		SeleCourse[] ans = new SeleCourse[MAXN];		// ����ѯ 100�ſγ�
		for(SeleCourse x: SelCouArr) {
			if(x == null)
				break;
			if(x.getSid().equals(stu.getSid()))
				ans[number++] = x;
			if(number >= MAXN) 
				break;
		}
		return ans;
	}
	
	public SeleCourse scByScid(SeleCourse selcou) {
		SeleCourse ans = null;
		for(SeleCourse x: SelCouArr) {
			if(x == null) 
				break;
			if(x.getScid().equals(selcou.getScid())) {
				ans = x;
				break;
			}
		}
		return ans;
	}
	
	public static boolean isExist(SeleCourse selcou) {
		boolean state = false;
		for(SeleCourse x: SelCouArr) {
			if(x == null) break;
			if(x.getScid().equals(selcou.getScid()) || x.getCsid().equals(selcou.getCsid()) && x.getSid().equals(selcou.getSid())) {
				state = true; break;
			}	
		}
		return state;
	}
	
	public static String Randomscid() {  // 00001 ~ 99999
		int MAX_ = 100000;
		return String.format("%05d", (int) (Math.random() * MAX_ + 1));
	}
	
	public static int getOffset() {
		return offset;
	}

	public static void setOffset(int offset) {
		SCArray.offset = offset;
	}

	public static int getAmount() {
		return amount;
	}

	public static int getLength() {
		return length;
	}

	public static SeleCourse[] getSelCouArr() {
		return SelCouArr;
	}
}
