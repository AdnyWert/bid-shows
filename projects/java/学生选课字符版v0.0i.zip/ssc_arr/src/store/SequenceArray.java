package store;

import model.Courses;

public class SequenceArray {		// ˳������
	private int amount;		// Ԫ�صĸ���
	private int length;		// ����
	private int offset;		// ����������� 0

	public int getOffset() {
		return offset;
	}

	public void setOffset(int offset) {
		this.offset = offset;
	}

	public int getAmount() {
		return amount;
	}

	public void setAmount(int amount) {
		this.amount = amount;
	}

	public void setLength(int length) {
		this.length = length;
	}

	public int getLength() {
		return length;
	}


}
