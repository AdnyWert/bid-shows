package store;

import model.Courses;
import model.Teachers;

public class CouArray {
	private static int amount;
	private static int length;
	private static int offset;		// ����������� 0
	private static Courses[] CouArr;
	
	static {	// ��ʼ��
		offset = 10;
		CouArr = new Courses[length];
	}
	
	public static boolean add(Courses cou) {	// ����һ����Ŀ
		boolean state = true;
		state = !isExist(cou);		// ������Ϊ true !true Ϊ false
		if(state) {
			if(amount >= length) // ���ݳ��ȴ������鳤��
				CouArr = move(CouArr, length, offset);
			CouArr[amount++] = cou;
		}
		return state;
	}
	
	public static boolean delete(Courses cou) {		// ɾ��һ����Ŀ
		boolean state = false;
		if(cou == null)
			state = false;
		else
			for(int i = 0; i < amount; i++)
				if(CouArr[i].getCid().equals(cou.getCid())) {
					System.arraycopy(CouArr, i+1, CouArr, i, amount-i);	// ����ת��
					state = true;
					amount--; CouArr[amount] = null;
					break; 
				}
		return state;
	}
	
	public static Courses[] move(Courses[] CouArr, int length, int offset) {	// ����ת��
		CouArray.length = length + offset;
		Courses[] newCouArr = new Courses[CouArray.length];
		System.arraycopy(CouArr, 0, newCouArr, 0, amount);	// ����ת��
		return newCouArr;
	}
	
	public static Courses couByTid(Courses cou) {
		Courses ans = null;
		if(cou == null)
			ans = null;
		else
			for(Courses x: CouArr) {
				if(x == null)
					break;
				if(x.getCid().equals(cou.getCid())) {
					ans = x;
					break;
				}
			}		
		return ans;
	}
	
	public static boolean isExist(Courses cou) {
		boolean state = false;
		if(cou == null)
			state = false;
		else
			for(Courses x: CouArr) {
				if(x == null) break;
				if(x.getCid().equals(cou.getCid())) {
					state = true; break;
				}
			}
		return state;
	}
	
	
	public static int getOffset() {
		return offset;
	}

	public static void setOffset(int offset) {
		CouArray.offset = offset;
	}

	public static int getAmount() {
		return amount;
	}

	public static int getLength() {
		return length;
	}

	public static Courses[] getCouArr() {
		return CouArr;
	}
}
