package utils;

import model.SeleCourse;
import store.SCArray;

public class StuOperate {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
	public boolean selectSC(SeleCourse selcou) {
		return SCArray.add(selcou);
	}
	public boolean deleteSC(SeleCourse selcou) {
		return SCArray.delete(selcou);
	}
}
